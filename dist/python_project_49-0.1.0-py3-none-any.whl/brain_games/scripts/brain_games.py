#!/usr/bin/env python3
from brain_games.cli import welcome_user


def welcom():
    print('Welcome to the Brain Games!')


def main():
    welcom()
    welcome_user()


if __name__ == '__main__':
    main()
